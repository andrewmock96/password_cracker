use sha2::{Sha256, Digest};
use std::io;
use std::time::Instant;

fn main() {
    let prompt = "Please enter the password to hash and crack: ";
    let password = get_user_input(prompt);

    let hashed_password = hash_password(&password);

    println!("\nOriginal password: {}", password);
    println!("Hashed password:   {}\n", hashed_password);

    // Crack plain password
    let start_plain = Instant::now();
    let cracked_plain = brute_force_password(&password);
    let duration_plain = start_plain.elapsed();

    match cracked_plain {
        Some(p) => println!("Cracked plain password: '{}' in {:?}", p, duration_plain),
        None => println!("Failed to crack the plain password"),
    }

    // Crack hashed password
    let start_hashed = Instant::now();
    let cracked_hashed = brute_force_hashed_password(&hashed_password);
    let duration_hashed = start_hashed.elapsed();

    match cracked_hashed {
        Some(p) => println!("Cracked hashed password: '{}' in {:?}", p, duration_hashed),
        None => println!("Failed to crack the hashed password"),
    }
}

/// Reads user input and returns a trimmed String
fn get_user_input(prompt: &str) -> String {
    println!("{}", prompt);
    let mut input = String::new();
    io::stdin().read_line(&mut input).expect("Failed to read line");
    input.trim().to_string()
}

/// Hashes a password using SHA-256 and returns it as a hex string
fn hash_password(password: &str) -> String {
    let mut hasher = Sha256::new();
    hasher.update(password.as_bytes());
    let result = hasher.finalize();
    hex::encode(result)
}

/// Brute-force the plain text password by direct comparison
fn brute_force_password(password: &str) -> Option<String> {
    let charset = "abcdefghijklmnopqrstuvwxyz0123456789";
    let max_len = 6;

    let charset_vec: Vec<char> = charset.chars().collect();

    for len in 1..=max_len {
        let mut guess_vec = Vec::with_capacity(len);
        if let Some(found) = try_password(&charset_vec, &mut guess_vec, len, password) {
            return Some(found);
        }
    }

    None
}

/// Helper function for plain password brute-force
fn try_password(
    charset: &[char],
    guess: &mut Vec<char>,
    max_len: usize,
    password: &str,
) -> Option<String> {
    if guess.len() == max_len {
        let attempt: String = guess.iter().collect();
        if attempt == password {
            return Some(attempt);
        }
        return None;
    }

    for &c in charset {
        guess.push(c);
        if let Some(found) = try_password(charset, guess, max_len, password) {
            return Some(found);
        }
        guess.pop();
    }

    None
}

/// Brute-force the hashed password by hashing every guess and comparing
fn brute_force_hashed_password(hashed_password: &str) -> Option<String> {
    let charset = "abcdefghijklmnopqrstuvwxyz0123456789";
    let max_len = 6;

    let charset_vec: Vec<char> = charset.chars().collect();

    for len in 1..=max_len {
        let mut guess_vec = Vec::with_capacity(len);
        if let Some(found) = try_hashed(&charset_vec, &mut guess_vec, len, hashed_password) {
            return Some(found);
        }
    }

    None
}

/// Helper function for hashed password brute-force
fn try_hashed(
    charset: &[char],
    guess: &mut Vec<char>,
    max_len: usize,
    target_hash: &str,
) -> Option<String> {
    if guess.len() == max_len {
        let attempt: String = guess.iter().collect();
        let mut hasher = Sha256::new();
        hasher.update(attempt.as_bytes());
        let attempt_hash = hex::encode(hasher.finalize());
        if attempt_hash == target_hash {
            return Some(attempt);
        }
        return None;
    }

    for &c in charset {
        guess.push(c);
        if let Some(found) = try_hashed(charset, guess, max_len, target_hash) {
            return Some(found);
        }
        guess.pop();
    }

    None
}